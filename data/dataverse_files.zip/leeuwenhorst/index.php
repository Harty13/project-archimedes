<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>Go Up</title>
	<META HTTP-EQUIV="Refresh" <META HTTP-EQUIV="Refresh" CONTENT="1; url=../index.php">

</head>

<body>
<a href="../">Go Up</a>
</body>
</html>
