<dl id="search">
	</dd>
	<dt>Search Catalogue</dt>
	<dd>
<form method="GET" action="https://search.socialhistory.org/Search/Results" name="searchForm">
  <input type="hidden" name="type" value="AllFields">
  <input type="text" name="lookfor" size="33">
  <input type="submit" name="submit" value="Search" style="background-color:#50739B; color:#fff;">
</form>
	</dd>
	<dt>Search Website</dt>
	<dd>
<form id="cse-search-box" action="https://www.iisg.nl/g-search.php">
  <input type="hidden" name="cx" value="004952896452667479768:by8xtehgxf4">
  <input type="hidden" name="ie" value="UTF-8">
  <input type="text" name="q" size="33">
  <input type="submit" name="sa" value="Search" style="background-color:#50739B; color:#fff;">
</form>
<br>
</dl>


