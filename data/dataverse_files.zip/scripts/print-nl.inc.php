<?php 
// MENU ITEM

$label = "Printversie";
$language = "nl";
include "print.inc.php";
