<div class="layer1">
<div class="logo-nl">
<a href="https://socialhistory.org/nl/"><img class="iisg" src="sites/all/themes/iisg/images/logo-nl.png" width="495" height="94" border="0" alt="IISG"></a></div>
<div class="payoff-nl">Onderzoekt en verzamelt de<br>geschiedenis van werk, werkenden en<br>arbeidsverhoudingen wereldwijd</div>
</div>

<br clear="all">

<div class="layer2">
<div class="mainmenu"><a href="https://socialhistory.org/nl/onderzoek">onderzoek</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/nl/publicaties">publicaties</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/nl/collecties">collecties</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/nl/dienstverlening">dienstverlening</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/nl/highlights">highlights</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/nl/over-iisg">over iisg</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/nl/nieuws-agenda">nieuws</a>
</div> 
<div class="helpmenu"><a href="https://socialhistory.org/nl/dienstverlening/faq">help</a></div>
</div> 

<br clear="all">
