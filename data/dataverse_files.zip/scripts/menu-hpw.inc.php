<dt>Prices and Wages</dt>
<dd><a href="/hpw/">Index</a></dd>
<dd><a href="/hpw/index.php#new">What's new</a></dd>
<dd><a href="/hpw/data.php">List of Datafiles</a></dd>
<dd><a href="/hpw/calculate.php">Value of the Guilder / Euro</a></dd>
<dd><a href="/hpw/link.php">Index to websites</a></dd>
<dd><a href="/hpw/conference.php">Conferences</a></dd>
