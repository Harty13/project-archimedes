<div class="layer1">
<div class="logo">
<a href="https://socialhistory.org/"><img class="iisg" src="sites/all/themes/iisg/images/logo-en.png" width="454" height="94" border="0" alt="IISH"></a></div>
<div class="payoff">Conducts research and collects data<br>on the global history of labour,<br>workers, and labour relations</div>
</div>

<br clear="all">

<div class="layer2">
<div class="mainmenu"><a href="https://socialhistory.org/en/research">research</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/en/publications">publications</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/en/collections">collections</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/en/services">services</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/en/highlights">highlights</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/en/about">about iish</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/en/news-events">news</a>
</div> 
<div class="helpmenu"><a href="https://socialhistory.org/en/services/faq">help</a></div>
</div> 

<br clear="all">
