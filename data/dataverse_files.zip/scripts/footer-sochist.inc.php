<br clear="all">

<div class="layer4">

<div class="footermenu1">
<span class="footertitle"><a href="https://socialhistory.org/en/colofon">colophon</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/en/license">license</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/en/privacy">privacy</a></span><br><br><br>
<em>An Institute of the Royal Netherlands Academy of Arts and Sciences (KNAW)</em></div>

<div class="footermenu2">
<span class="footertitle">address</span>
<hr>
P.O. Box 2169<br>
1000CD Amsterdam<br><br>
Cruquiusweg 31<br>
1019 AT  Amsterdam<br>
The Netherlands
</div>

<div class="footermenu2">
<span class="footertitle">opening hours</span>
<hr>
The Reading Room is open<br>
Mon: 10 am till 5 pm<br>
Tue-Fri: 9 am till 5 pm<br><br>
<a href="https://socialhistory.org/en/contact">ask@iisg.nl</a>
</div>

<div class="footermenu2">
<span class="footertitle">contact</span>
<hr>
T + 31 20 6685866<br>
F + 31 20 6654181<br>
E <a href="https://socialhistory.org/en/contact">info@iisg.nl</a><br><br>
<a href="http://www.facebook.com/pages/International-Institute-of-Social-History/206886206034167"><img src="sites/all/themes/iisg/images/facebook.png"></a> <a href="http://twitter.com/iisg_amsterdam"><img src="sites/all/themes/iisg/images/twitter.png"></a> <a href="http://www.linkedin.com/company/iisg"><img src="sites/all/themes/iisg/images/linkedin.png"></a>
</div>
</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5303281-1");
pageTracker._trackPageview();
</script>
