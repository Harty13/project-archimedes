<br clear="all">

<div class="layer4">

<div class="footermenu1">
<span class="footertitle"><a href="https://socialhistory.org/nl/colofon">colofon</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/nl/license">licentie</a>&nbsp;&nbsp;&nbsp;<a href="https://socialhistory.org/nl/privacy">privacy</a></span><br><br><br>
<em>Een Instituut van de Koninklijke Nederlandse Akademie van<br> Wetenschappen (KNAW)</em></div>

<div class="footermenu2">
<span class="footertitle">adres</span>
<hr>
Postbus 2169<br>
1000CD Amsterdam<br><br>
Cruquiusweg 31<br>
1019 AT  Amsterdam<br>
Nederland
</div>

<div class="footermenu2">
<span class="footertitle">openingstijden</span>
<hr>
De studiezaal is geopend:<br>
ma: 10 tot 17 uur<br>
di-vr: 9 tot 17 uur<br><br>
<a href="https://socialhistory.org/nl/contact">vraag@iisg.nl</a>
</div>

<div class="footermenu2">
<span class="footertitle">contact</span>
<hr>
T + 31 20 6685866<br>
F + 31 20 6654181<br>
E <a href="https://socialhistory.org/nl/contact">info@iisg.nl</a><br><br>
<a href="http://www.facebook.com/pages/International-Institute-of-Social-History/206886206034167"><img src="sites/all/themes/iisg/images/facebook.png"></a> <a href="http://twitter.com/iisg_amsterdam"><img src="sites/all/themes/iisg/images/twitter.png"></a> <a href="http://www.linkedin.com/company/iisg"><img src="sites/all/themes/iisg/images/linkedin.png"></a>
</div>
</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5303281-1");
pageTracker._trackPageview();
</script>
